package com.raspberry.board.dto;

import lombok.Data;

@Data
public class MemberDto {
    private String uid;
    private String upwd;
    private String uname;
    private String ubirth;
    private String uemail;
    private String uphone_num;
    private String uaddr;
    private String ugender;
}
