package com.raspberry.board.dto;

import lombok.Data;

@Data
public class TaxMemberDto {
    private String tid;
    private String tpwd;
    private String tcom_name;
    private String tname;
    private String tcom_phonenum;
    private String tphone_num;
    private String tbus_num;
    private String tcar_kind;
}
