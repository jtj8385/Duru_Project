package com.raspberry.board.dto;

import lombok.Data;

@Data
public class ResBookDto {
    private String rb_uname;
    private String rtime;
    private int rhead_count;
    private String uid;
    private String rid;
}
