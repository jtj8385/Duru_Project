package com.raspberry.board.dto;

import lombok.Data;

@Data
public class ResMemberDto {
    private String rid;
    private String rpwd;
    private String rname;
    private String rbus_num;
    private String rphone_num;
    private String raddr;
    private String maindish;
    private String rnum;
    private String facil_size;
}
