package com.raspberry.board.dto;

import lombok.Data;

@Data
public class ProMemberDto {
    private String pid;
    private String ppwd;
    private String pcenter_name;
    private String pcenter_loc;
    private String pcenter_num;
    private String pbus_num;
}
