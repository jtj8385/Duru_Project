package com.raspberry.board.dao;

import com.raspberry.board.dto.ResBookDto;
import com.raspberry.board.dto.ResCheckDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ResBookDao {

    //예약 작성 메소드
    void addResBookInfo(ResBookDto resBookDto);

    //예약자 정보 출력 메소드
    List<ResBookDto> getResBookInfo(String rid);


}
